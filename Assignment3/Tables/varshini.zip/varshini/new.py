import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_excel('nnn.xlsx','Sheet1')
data = np.array(df)
fig,ax= plt.subplots()
ax.bar(data[0],data[1])

plt.xlabel("Life time (in hours)")
plt.ylabel("Number of lamps")
plt.show()